#!/usr/bin/env python

import sys
import string

for line in sys.stdin:
    line = line.split(',')
    key=line[2]
    value=line[1]
    print(str(key) + "\t" +  str(value))
