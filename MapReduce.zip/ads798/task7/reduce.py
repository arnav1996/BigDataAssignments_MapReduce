#!/usr/bin/env python

import sys
import string
import operator

currentkey = None
weekendlist = [5, 6, 12, 13, 19, 20, 26, 27]
ws = 0
wks = 0
for line in sys.stdin:
    line = line.strip()
    key, values = line.split('\t',1)
    key = key.strip()
    values = values.strip().split("-")
    date = int(values[2])
    if key==currentkey:
        if date in weekendlist:
            wks += 1
        else:
            ws += 1
    else:
        if currentkey:
            average_weekend = float(wks/8.00)
            average_week = float(ws/23.00)
            print(str(currentkey) + "\t" + "%.2f" %average_weekend + "," + "%.2f" %average_week)

        currentkey = key
        wks = 0
        ws = 0
        if date in weekendlist:
            wks += 1
        else:
            ws += 1

average_weekend = float(wks/8.00)
average_week = float(ws/23.00)
print(str(currentkey) + "\t" + "%.2f" %average_weekend + "," + "\t" + "%.2f"  %average_week)
