#!/usr/bin/env python

import sys
import string

for line in sys.stdin:
    line = line.strip()
    row = line.split(',')
    key = row[14]
    key1 = row[16]
    value=1
    print(str(key) + "," + str(key1) + "\t" + str(value))
