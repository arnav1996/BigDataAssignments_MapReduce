#!/usr/bin/env python

import sys
import string

currentkey = None
count = 0
v = ['key', count]

for line in sys.stdin:
    line = line.strip()
    key, values = line.split('\t',1)

    if key==currentkey:
        count += 1
    else:
        if currentkey:
            if count > v[1]:

                v[0] = currentkey
                v[1] = count

        currentkey = key
        count = 1

if count > v[1]:

    v[0] = currentkey
    v[1] = count

print(str(v[0])+"\t"+str(v[1]))
