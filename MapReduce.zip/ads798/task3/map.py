#!/usr/bin/env python
import sys
import string
import csv

for line in sys.stdin:

    line=line.strip()
    row = csv.reader([line], delimiter=',')
    row = list(row)[0]
    key = row[2]
    try:
       value = float(row[12])
    except:
       continue
    print(str(key) + "\t" + str(value) + " 0.00")
