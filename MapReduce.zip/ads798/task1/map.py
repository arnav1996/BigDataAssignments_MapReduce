#!/usr/bin/env python
# Map function to find all parking violations that have been paid
# Task - 1

import sys
import string
import csv

# input comes from STDIN (stream data from csv file that goes to the program)
for line in sys.stdin:

	#Remove leading and trailing whitespace
	line = line.strip()
	
	#Parse columns from single csv row
	row = csv.reader([line], delimiter=',')	
	row = list(row)[0]
	
	#Generate the necessary key-value pairs
	if (len(row) == 22):
		value = row[14],row[6],row[2],row[1]
		print(str(row[0]) + '\t' + str(value))
	else:
		value = row[1], row[5], row[7],row[9]
		print(str(row[0]) + '\t' + str(value))

