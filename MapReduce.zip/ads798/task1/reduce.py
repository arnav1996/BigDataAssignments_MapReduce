#!/usr/bin/env python
# Reduce function to find all parking violations that have been paid
# Task - 1

import sys
import string

currentkey = None
count = 0
previousvalue = None

# input comes from STDIN (stream data that goes to the program)
for line in sys.stdin:

	#Remove leading and trailing whitespace
	line = line.strip()
	
	#Get key/value
	key, value = line.split('\t',1)
	key = key.strip()
	
	#If we are still on the same key...
	if key == currentkey:
		count = count + 1
	
	#Otherwise, if this is a new key...
	else:
	
		#If this is a new key and not the first key we've seen
		if currentkey:
		
			#compute/output result to STDOUT
			if count == 1:
				print(str(currentkey) + '\t' + str(previousvalue).replace('(','').replace(')','').replace("'",''))
		
		#Process input for new key
		currentkey = key
		count = 1
		previousvalue = value

#Compute/output result for the last key		
if count == 1:
	print(str(key) + '\t' + str(value).replace('(','').replace(')','').replace("'",''))	

