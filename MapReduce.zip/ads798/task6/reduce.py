#!/usr/bin/env python

import sys
import string

currentkey = None
count = 0
mv = dict()

for line in sys.stdin:

    line = line.strip()

    key, value = line.split('\t',1)
    key=key.strip()
    value=value.strip()
    if key==currentkey:
        count += 1
    else:

        if currentkey:
            mv[currentkey] = count
        currentkey = key
        count = 1
mv[currentkey] = count
optt=dict(sorted(mv.items(), key=lambda x: x[1],reverse=True)[:20])
for k,v in optt.items():
    k = k.split(",")
    print(str(k).replace("'","").replace("[","").replace("]","") + "\t" + str(v))
