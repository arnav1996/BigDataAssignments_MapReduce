#!/usr/bin/env python

import sys
import string
import csv

for line in sys.stdin:

    line=line.strip()
    row = csv.reader([line], delimiter=',')
    row = list(row)[0]
    print(str(row[14]) +  "," + " " + str(row[16]) + "\t" + "1")
    
