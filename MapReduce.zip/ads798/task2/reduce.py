#!/usr/bin/env python

import sys
import string

currentkey = None
count = 0

# input comes from STDIN (stream data that goes to the program)
for line in sys.stdin:

    #Remove leading and trailing whitespace
    line = line.strip()

    #Get key/value
    key, value = line.split('\t', 1)

    #If we are still on the same key...
    if currentkey == key:
        count += 1
		
    #Otherwise, if this is a new key...	
    else:

        #If this is a new key and not the first key we've seen		
        if currentkey:
		
            #compute/output result to STDOUT		
            print(str(currentkey) + '\t' + str(count))
			
        #Process input for new key			
        currentkey = key
        count = 1

#Compute/output result for the last key		
print(str(key) + '\t' + str(count))

