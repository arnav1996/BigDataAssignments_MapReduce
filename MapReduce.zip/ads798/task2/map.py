#!/usr/bin/env python

import sys
import string



for line in sys.stdin:
    line = line.strip()
    row = line.split(',')
    key = row[2]
    value = 1
    
    try:
       print(str(key)+ "\t" + str(value))
    except:
       continue
