#!/usr/bin/env python

import sys

current_rec = None
current_count = 0
rec = None

for line in sys.stdin:
    line = line.strip()
    rec1,rec2, count = line.split('\t', 2)
    rec= rec1 + "\t" + rec2 
    try:
        count = int(count)
    except:
        continue

    if current_rec == rec:
        current_count += count
    else:
        if current_rec is not None:
            ids = current_rec.split('\t')
            if ids[0] == 'aMake':
                print('{0}\t{1},{2}'.format('vehicle_make', ids[1], current_count))
            else:
                print('{0}\t{1},{2}'.format('vehicle_color', ids[1], current_count))
        current_count = count
        current_rec = rec

if current_rec != None:
    ids = current_rec.split('\t')
    if ids[0] == 'aMake':
        print('{0}\t{1},{2}'.format('vehicle_ake', ids[1], current_count))
    else:
        print('{0}\t{1},{2}'.format('vehicle_color', ids[1], current_count))



