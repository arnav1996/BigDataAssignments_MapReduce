#!/usr/bin/env python

import sys
import string
import csv

for line in sys.stdin:
     line=line.strip()
     r = csv.reader([line], delimiter=',')
     r = list(r)[0]
     m = r[20]
     c = r[19]

     if m:
        print('{0}\t{1}\t{2}'.format('aMake', m, 1))
     else:
        print('{0}\t{1}\t{2}'.format('aMake', 'NONE', 1))

     if c:
        print('{0}\t{1}\t{2}'.format('bColor', c, 1))
     else:
        print('{0},\t{1}\t{2}'.format('bColor', 'NONE', 1))

