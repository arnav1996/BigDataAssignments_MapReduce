#!/usr/bin/env python

import sys
import string
import csv
 
for line in sys.stdin:
    line = line.strip()
    row = csv.reader([line], delimiter=',')	
    row = list(row)[0]
    key = row[16]
    value=1
    print(str(key) + "\t" + str(value))
